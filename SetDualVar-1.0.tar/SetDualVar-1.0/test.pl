use SetDualVar;

SetDualVar $x, "hello", 4.12;

print $x+1,"\n",$x.'|',"\n";
